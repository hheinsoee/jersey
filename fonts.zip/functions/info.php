<?php
function siteinfo($val)
{
    switch ($val) {
        case 'name':
            return "RY sports corner";
            break;
        case 'description':
            return "ဂျာစီဖောင့်စုစည်းမှု";
            break;

        default:
            # code...
            break;
    }
}
